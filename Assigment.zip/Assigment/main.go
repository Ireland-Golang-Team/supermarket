//CS5741 SUPERMARKET CHECKOUT SIMULATION ASSIGNMENT
//*****************************************************//
//Submitted By Msc Group 1
//Team members :
//Praveen Balesha.Talavar - 20089236
//Riya.Joe - 20023693
//Tianchi.Jiang -20111479
//Tongling.Liu -20006764
//Junke.Yu -19141785

package main

import (
	"fmt"
	"math/rand"
	"sync"
	"time"
)

var lostnum int = 0                //The number of lost customers
var finishnum int = 0              //The number of finish checkout consumer
var totalWait float64 = 0          //The total wait time for all consumer
var totalItem int = 0              //The total no of products for the processed consumers
var numCashier int                 // The no of cashiers(Scanners) installed
var numLessCashier int             //The no of express cashiers(Scanners) insatlled
var consumernum int                //The no of consumers(customers) in a shop
var globalmutex sync.Mutex         //Used to lock the no of consumers
var globalmutexwaittime sync.Mutex //Used to lock the total wait time
var globalCashierGroup sync.Mutex  //Used to lock the cashier group
var consumers []*Consumer          //used to store data of type consumer

//declare structure definition for Weather,Cashier,Consumer

type Weather struct {
	BeginTime     int64
	weatherEffect int
}

type Cashier struct {
	Id        int
	WaitGroup chan int
	Limit     int
	// lock sync.Mutex
	BeginTime int64
	checkTime float64
}
type Consumer struct {
	Id            int
	ProductNumber int
	Checkspeed    float64
	WaitTime      int
	BeginTime     int64
}

//changeWeather function  helps in setting the weather based on time
func (w *Weather) changeWeather() {
	for {
		time.Sleep(time.Millisecond * 100)

		time := time.Now().UnixNano()
		gap := time - w.BeginTime
		// change the weatherEffect
		if gap%(3*1e10) > 2*1e10 {
			w.setWeather(3)
		} else if gap%(3*1e10) > 1e10 {
			w.setWeather(2)
		} else {
			w.setWeather(1)
		}
	}
}

// setWeather function helps in setting value for weatherEffect of structure variable weather
func (w *Weather) setWeather(value int) {
	w.weatherEffect = value
}

//setLimit function helps in setting the product limit a cashier can serve
func (c *Cashier) setLimit(inVal int) {
	c.Limit = inVal
}

//addConsumer function will add the consumer id into the cashiers waitgroup channel
func (c *Cashier) addConsumer(inVal int) {
	c.WaitGroup <- inVal

}

//setBeginTime function assign current time in Unix Nano to BeginTime of the Cashier
func (c *Cashier) setBeginTime() {

	time := time.Now().UnixNano()
	c.BeginTime = time
}

//doCheckout function processes each consumer inside  the waitgroup  channel,it calculates the waittime and total no of customer processed
func (c *Cashier) doCheckout(wg *sync.WaitGroup) {
	for {

		if len(c.WaitGroup) > 0 {
			consumerID := <-c.WaitGroup

			TimeNow := time.Now().UnixNano()
			left := float64(TimeNow - consumers[consumerID].BeginTime)
			waitTime := left / 1e9
			globalmutexwaittime.Lock()
			totalWait = totalWait + waitTime
			globalmutexwaittime.Unlock()

			consumerchecktime := int(consumers[consumerID].Checkspeed * float64(consumers[consumerID].ProductNumber) * 1000.0) //millisecond
			c.checkTime = c.checkTime + float64(consumerchecktime)/1000.0                                                      //second
			time.Sleep(time.Millisecond * time.Duration(consumerchecktime))
			globalmutexwaittime.Lock()
			finishnum++
			fmt.Printf("Consumer %d served by Cashier %d  had %d products were processed after a wait time of  %f \n", consumerID, c.Id, consumers[consumerID].ProductNumber, waitTime)
			fmt.Printf("Total No of customers processed %d\n", finishnum)
			globalmutexwaittime.Unlock()
			wg.Done()
		}
	}
}

//setWaitTime function generates random no between 0 and 20 for random arrival rate of customers at checkout
func (c *Consumer) setWaitTime() {
	num := rand.Intn(20)
	c.WaitTime = num
}

//setBeginTime function sets the current time as the customers BeginTime
func (c *Consumer) setBeginTime() {

	time := time.Now().UnixNano()
	c.BeginTime = time
}

//setProductNumber function is a pseudorandom function used to generate product number between 0 and 200 for the customers
func (c *Consumer) setProductNumber() {
	num := rand.Float64()
	if num >= 0.2 {
		c.ProductNumber = rand.Intn(194) + 6
		test := rand.Intn(100)
		if test >= 99 {
			c.ProductNumber = rand.Intn(194) + 6
		} else if num >= 98 {
			c.ProductNumber = rand.Intn(174) + 6
		} else if num >= 97 {
			c.ProductNumber = rand.Intn(154) + 6
		} else if num >= 95 {
			c.ProductNumber = rand.Intn(134) + 6
		} else if num >= 90 {
			c.ProductNumber = rand.Intn(114) + 6
		} else if num >= 50 {
			c.ProductNumber = rand.Intn(70) + 6
		} else {
			c.ProductNumber = rand.Intn(20) + 6
		}
	} else {
		c.ProductNumber = rand.Intn(4) + 1

	}
}

//setCheckspeed function  is a pseudorandom function used to generate processing time per product varying from 0.6 to 5
func (c *Consumer) setCheckspeed() {
	num := rand.Intn(100)
	if num >= 99 {
		c.Checkspeed = 5.0 + rand.Float64()
	} else if num >= 98 {
		c.Checkspeed = 4.0 + rand.Float64()
	} else if num >= 97 {
		c.Checkspeed = 3.0 + rand.Float64()
	} else if num >= 95 {
		c.Checkspeed = 2.0 + rand.Float64()
	} else if num >= 90 {
		c.Checkspeed = 1.0 + rand.Float64()
	} else {
		c.Checkspeed = float64(rand.Intn(50)+50) / 100
	}
}

// findQueue function is used to assign consumers into the cashiers waitgroup channel for performing doCheckout()
func (c *Consumer) findQueue(cashiers []*Cashier, w *Weather, wg *sync.WaitGroup) {
	var num int = -1
	var cap int = 6
	time.Sleep(time.Second * time.Duration(c.WaitTime*w.weatherEffect)) // Random time arrival at checkout for consumer based on weatherEffect
	globalCashierGroup.Lock()
	if c.ProductNumber <= 5 {
		for i := 0; i < numLessCashier; i++ {
			if len(cashiers[i].WaitGroup) < cap {
				num = i
				cap = len(cashiers[i].WaitGroup)

			}
		}
	}

	if c.ProductNumber > 5 || num < 0 {
		for i := numLessCashier; i < numCashier; i++ {
			if len(cashiers[i].WaitGroup) < cap {
				num = i
				cap = len(cashiers[i].WaitGroup)

			}
		}
	}
	if num < 0 {
		globalmutex.Lock()
		lostnum++
		fmt.Printf(" The Consumer %d left the store \n", c.Id)
		fmt.Printf(" The Total No of customers that left the store untill now : %d \n", lostnum)
		globalmutex.Unlock()
		wg.Done()
	} else {
		c.setBeginTime()
		globalmutex.Lock()
		totalItem = totalItem + c.ProductNumber
		cashiers[num].addConsumer(c.Id)
		globalmutex.Unlock()
	}
	globalCashierGroup.Unlock()

}

//********************Main**************************************//
func main() {
	//total no of cashiers be 8
	fmt.Println("Enter Number of Cashiers :") //Read from user :Max 6
	fmt.Scanln(&numCashier)
	fmt.Println("Enter Number of Express Cashiers:") //Read from user :Max 2
	fmt.Scanln(&numLessCashier)
	fmt.Println("Enter Number of Consumers:") //Read from user
	fmt.Scanln(&consumernum)
	now := time.Now().UnixNano() // calucalate current time
	randomweather := Weather{BeginTime: now, weatherEffect: 1}
	go randomweather.changeWeather() //start weather agent
	cashiers := make([]*Cashier, numCashier)
	var wg sync.WaitGroup

	for i := 0; i < numCashier; i++ {
		cashiers[i] = &Cashier{
			Id: i, WaitGroup: make(chan int, 6), checkTime: 0.0} //waitgroup channel  will contain the Customers to be processed
		if i < numLessCashier {
			cashiers[i].setLimit(5)
		} else {
			cashiers[i].setLimit(200)
		}
		cashiers[i].setBeginTime()
		go cashiers[i].doCheckout(&wg) //start cashier agent
	}

	for i := 0; i < consumernum; i++ {
		consumers = append(consumers, &Consumer{
			Id: i})
		consumers[i].setProductNumber()
		consumers[i].setCheckspeed()
		consumers[i].setWaitTime()
		wg.Add(1)
		go consumers[i].findQueue(cashiers, &randomweather, &wg) //adds consumers to  cashiers' waitgroup channel

	}
	wg.Wait()
	totalutilization := 0.0 //total checkout time
	TimeNow := time.Now().UnixNano()
	fmt.Println("*********Simulation Compelete**********")
	fmt.Printf("Total %d consumers who left the shop without purchasing \n", lostnum)
	fmt.Printf("Total No of products processed  : %d \n", totalItem)
	fmt.Printf("The Average No of products per trolley %f \n", float64(totalItem)/float64(finishnum))
	fmt.Printf("Average customer wait time %f\n", totalWait/float64(finishnum))
	totalCashierTime := 0.0
	for i := 0; i < numCashier; i++ {
		left := float64(TimeNow-cashiers[i].BeginTime) / 1e9
		totalCashierTime = totalCashierTime + left
		totalutilization = totalutilization + cashiers[i].checkTime
		fmt.Printf("Cashier %d  has utilization  of %f\n", i, float64(cashiers[i].checkTime)*100.0/left)
	}
	fmt.Printf("Average Checkout utilization %f\n", float64(totalutilization*100.0)/totalCashierTime)
}

//*******************End******************************************//
